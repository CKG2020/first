package com.example.ManyToMany;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "stu_course", schema = "db1", catalog = "")
public class StuCourseEntity {
}
