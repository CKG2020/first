package com.proxy.xxx.tools;

public interface IRunanble {
    void run();
}
