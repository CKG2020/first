package com.proxy.test;

public interface Subject {
    public  void  request();
}
